int Euclid_recursive_GCD(int a, int b) {
    if (b == 0) return a;
    return Euclid_recursive_GCD(b, a % b);
}
int Euclid_repeated_GCD(int a, int b) {
    int temp;
    while (b != 0) {
        temp = a % b;
        a = b;
        b = temp;
    }
    return a;
}