#include "euclid.h"

int main() {
	Test();
	return 0;
}