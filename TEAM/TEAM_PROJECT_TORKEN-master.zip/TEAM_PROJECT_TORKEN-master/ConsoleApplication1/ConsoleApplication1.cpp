﻿#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <Windows.h>
#include <conio.h>
#include <time.h>
#include <string.h>

#define SIZE 10
#define STRING_SIZE 512

typedef struct date {
	int year[SIZE];
	int month[SIZE];
	int day[SIZE];
} DAYS;
typedef struct data {
	DAYS date;
	int money[SIZE];
	char reason[SIZE][STRING_SIZE];
	char work[SIZE][STRING_SIZE];
}DATA;


DATA read_torken_struct()
{
	DATA D;
	int i = 0;
	char str[STRING_SIZE];
	char tmp[STRING_SIZE];

	FILE* fp=NULL;
	fp = fopen("data.txt", "r");
	if (fp == NULL)
		exit(1);

	while (fgets(str, STRING_SIZE, fp) != NULL)
	{
		printf("--%s\n", str);

		strcpy(tmp, strtok(str, "|"));
		D.money[i] = atoi(strtok(NULL, "|"));
		strcpy(D.reason[i], strtok(NULL, "|"));
		strcpy(D.work[i], strtok(NULL, "|"));
		D.date.year[i] = atoi(strtok(tmp, "-"));
		D.date.month[i] = atoi(strtok(NULL, "-"));
		D.date.day[i] = atoi(strtok(NULL, "-"));
		i++;
	}


	fclose(fp);
	return D;
}
/*
void load_info(const char* txt, data d[])
{
	FILE fp;
	fp = fopen(txt, "r");
	//2021-04-21 | -5000, 2000, 90000, 40000, 41115415465436546 |음료, NULL, 안녕, 나도, 히히 | 테이터에티어, NULL, NULL, NULL,|/
	int size = sizeof(data);
	charstr = (char*)malloc(size);
	fgets(str ,MAX_INFO_SIZE ,fp);

	fclose(fp);
}
*/
int main()
{
	int i;
	DATA A;
	A = read_torken_struct();

	for (i = 0; i < 3; i++) {

		printf("\n\n");
		printf("A.date.year[0]: %d\n", A.date.year[i]);
		printf("A.date.month[0]: %d\n", A.date.month[i]);
		printf("A.date.day[0]: %d\n", A.date.day[i]);
		printf("A.money[0] = %d\n", A.money[i]);
		printf("A.reason[0] = %s\n", A.reason[i]);
		printf("A.work[0] = %s\n", A.work[i]);
	}

	return 0;
}