# algorithm_2team
## 알고리즘 2팀 A조 (202010754 소예찬)

```c
#include <stdio.h>
void find_number() 
{
	int i, find_num = 45; //찾고싶은 숫자 
	int num_box[8] = {45,20,60,35,10,55,90,85}; //숫자 목록
	
	for (i=0;i<8;i++){  //반복문을 활용하여 첫번째 배열부터 비교
		if (find_num == num_box[i]){
			printf("%d번째 순서에 있는 %d값을 찾았습니다. ",i+1,num_box[i]); //탐색완료 출력
			return; //함수 종료 
		}
	}
	printf("%d <- 목록에 없는 숫자입니다.",find_num); //배열에 찾는 숫자가 없어 조건문에 있는 return이 발동되지 않았으면 찾는 수가 없다는 것이므로 결과 출력
}

int main()
{

	find_number();
	
	return 0;
}

```
