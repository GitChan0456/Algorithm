# algorithm_2team
## 알고리즘 2팀 A조 (202010754 소예찬)

가짜 동전 찾기 알고리즘

```c
#include <stdio.h>
int weight(int groupA_first, int groupA_last, int groupB_first, int groupB_last, int fcoin)
{
	if (groupA_first <= fcoin && fcoin <= groupA_last)
		return -1;//코인이 좌측에 있으면 -1반환
	if (groupB_first <= fcoin && fcoin<= groupB_last)
		return 1; //코인이 우측에 있으면 1반환
	else
		return 0; 
}

int find_fake_coin(int start, int end)
{
	if (start == end) //start와 end가 같아질경우 탐색이 모두 끝났다는 것이므로 종료
		return start;
		
	int fake_coin = 500; //가짜 동전의 위치 설정
	int a_first, a_end, mid, b_first, b_end;
	
	mid = (end - start + 1) / 2; //중간값
	
	a_first = start; //좌측 그룹의 첫번째 수
	a_end = start + mid - 1; //좌측 그룹의 마지막 수
	b_first = start + mid; //우측 그룹의 첫번째 수
	b_end = b_first + mid - 1; //우측 그룹의 마지막 수
	
	
	if (weight(a_first, a_end, b_first, b_end, fake_coin) == -1) { //코인이 좌측에 있음
		return find_fake_coin(a_first, a_end); //좌측그룹을 인자로 넘겨 재귀함수 호출
	}
	else if (weight(a_first, a_end, b_first, b_end, fake_coin) == 1) { //코인이 우측에 있음
		return find_fake_coin(b_first, b_end); //우측그룹을 인자로 넘겨 재귀함수 호출
	}
	else {
		return end;
	}
		
}

int main()
{
	int coins = 1024; //동전의 개수
	printf("fake coin의 위치는: %d입니다.", find_fake_coin(0, coins-1));

	return 0;
}


```
###수정 후 코드
기존코드에서 할 수 없던 동전이 홀수개일 경우도 올바르게 처리하도록 코드를 수정하였고 기존에 A그룹 B그룹 나누어 함수에 넘어가는 인자가 많아지므로 직관성이 떨어져 코드를 수정하였습니다. 또한 가짜 동전을 정수로 직접 지정하지 않고 난수로 설정하여 프로그램에서 자체 설정하도록 하여 사용자가 알 수 없도록 수정 하였습니다.
```c

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int fake_coin; 
int weight(int A_num, int half, int B_num, int fake_coin)
{
	if (A_num <= fake_coin && fake_coin <= half)
		return -1;//코인이 좌측에 있으면 -1반환
	if (half + 1 <= fake_coin && fake_coin <= B_num)
		return 1; //코인이 우측에 있으면 1반환
	else
		return 0; //가짜 동전이 여기 없음 
}

int find_fake_coin(int start, int end)
{
	if (start == end) {
		printf("찾았다!");
		return start;
	}

	int A_num = start, B_num = end, half=0, ex_coin = 0;
	int coin = B_num - A_num + 1;; //나눠야 할 코인의 개수
	
	if (coin % 2 == 0) {//짝수개 coin
		half = (B_num + A_num) / 2;
	}
	else {//홀수개 coin 
		ex_coin = B_num; //홀수일 경우 마지막 코인을 하나 빼두어 짝수로 만든다.
		B_num = B_num - 1; 
		half = (B_num + A_num) / 2;
	}

	// printf("A_num = %d, half = %d, B_num = %d 일때	", A_num, half, B_num); 에러 검출용... 

	if (weight(A_num, half, B_num, fake_coin) == -1) { //코인이 좌측에 있음
		return find_fake_coin(A_num, half);
	}
	else if (weight(A_num, half, B_num, fake_coin) == 1) { //코인이 우측에 있음
		return find_fake_coin(half + 1, B_num);
	}
	else { //코인이 좌측 우측에 없음 = 밖으로 빼둔 코인이 가짜임 
		return ex_coin;
	}

}

int main()
{
	int x, coins, fake;

	printf("동전의 개수 입력 : ");
	scanf("%d",&coins);
	
	srand((unsigned int)time(NULL));
	fake_coin = (rand() % coins) + 1;
	printf("가짜 동전을 숨겼습니다.\n");

	x = find_fake_coin(1, coins);
	printf("가짜동전의 위치 : %d", x);

	return 0;
}
```
